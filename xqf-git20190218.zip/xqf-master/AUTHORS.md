Creator
-------

* Roman Pozlevich <roma@botik.ru>


Maintainers
-----------

* Thomas Debesse <xqf@illwieckz.net>
* Artem Vorotnikov <artem@vorotnikov.me>
* Jordi Mallach <jordi@debian.org>
* Ludwig Nussel <ludwig.nussel@suse.de>
* Alex Burger <alex_b@users.sf.net>
* Bill Adams <bill@evilbill.org>


Contributors
------------

* Zack Middleton <zturtleman@gmail.com>
* Arnaud Bonatti <arnaud.bonatti@gmail.com>
* Jochen Baier <email@jochen-baier.de>
* Witold Piłat <witold.pilat@gmail.com>
* Victor BE <victorbe@users.sf.net>
* Jo Shields <directhex@apebox.org>
* Sven Joachim <svenjoac@gmx.de>
* Lars Wirzenius <liw@iki.fi>
* Gilles Crettenand <gilles.crettenand@liip.ch>
* Spanti Nicola <rydroid_dev@yahoo.com>
* Luca Camillo <kamy@tutorials.it>
* Alexander Hambalgo <balgo@users.sf.net>
* Ozkan Sezer <sezero@users.sf.net>
* Jorge Hodge <jhodge@users.sf.net>
* Steffen Pankratz <krat00@users.sf.net>
* Thomas Zajic <zlatk0@users.sf.net>
* Niklas Paulsson <niklas@student.adb.gu.se>
* Daniel O'Connor <doconnor@gsoft.com.au>
* Pete Toscano <pete@bubba.psi.com>
* Philipp Thomasi
* Jason Santos
* Matze Braun
* Andreas Schneider
* Ben Winslow
* Florian Riepler
* Mike Mestnik
* Simon Philips
* Luigi Auriemma


Translators
-----------

* Jordi Mallach <jordi@debian.org>
* Morten Brix Pedersen <morten@wtf.dk>
* Sami Laitinen <azmotus@gmail.com>
* Thomas Debesse <xqf@illwieckz.net>
* Michel Briand <michelbriand@free.fr>
* IR4 <gutzu@gmx.ch>
* Ludwig Nussel <ludwig.nussel@suse.de>
* Miłosz Kosobucki <mikomek@poczta.onet.pl>
* Artem Vorotnikov <artem@vorotnikov.me>
* Dan Korostelev <dan@ats.energo.ru>
* François Perichon


Packagers
---------

* Slash Bunny <demodevil@gmail.com>
* Jordi Mallach <jordi@debian.org>
* Ludwig Nussel <ludwig.nussel@suse.de>


See the Wiki page for more information: https://github.com/XQF/xqf/wiki/Contributors
